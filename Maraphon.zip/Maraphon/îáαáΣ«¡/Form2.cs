﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Марафон
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public string Email { get; set; }

        private void button2_Click(object sender, EventArgs e)
        {
            Начало db = new Начало();
            db.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool IsValidEmail(string eMail)
            {
                bool Result = false;
                try
                {
                    var eMailValidator = new System.Net.Mail.MailAddress(eMail);
                    Result = (eMail.LastIndexOf(".") > eMail.LastIndexOf("@"));
                }
                catch
                {
                    Result = false;
                };
                return Result;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}

