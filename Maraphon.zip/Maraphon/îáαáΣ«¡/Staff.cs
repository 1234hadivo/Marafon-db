namespace Марафон
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Staff")]
    public partial class Staff
    {
        public int StaffID { get; set; }

        [Required]
        [StringLength(80)]
        public string FullName { get; set; }

        [Required]
        [StringLength(100)]
        public string Email { get; set; }

        [Column(TypeName = "date")]
        public DateTime DateOfBrith { get; set; }

        [Required]
        [StringLength(10)]
        public string Gender { get; set; }

        public short? PositionID { get; set; }

        [Required]
        [StringLength(100)]
        public string PositionName { get; set; }

        [Required]
        [StringLength(100)]
        public string PositionDescription { get; set; }
    }
}
